//EXPECTED 4294967294
int main() {
  return 0 - 2;
}
