//EXPECTED 42
int main() {
  if(0)
    return 99;
  else
    return 42;
}
