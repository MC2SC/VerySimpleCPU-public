//EXPECTED 0
int main() {
  return (0 - 30) > (0 - 12);
}
