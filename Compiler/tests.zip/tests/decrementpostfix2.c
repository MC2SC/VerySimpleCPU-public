//EXPECTED 42
int main() {
  int a = 43;
  int b = 2;
  int c = a-b--;
  return b+c;
}
