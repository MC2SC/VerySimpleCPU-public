//EXPECTED 50

int main() {
  int j;
  int sum = 0;
  for (j = 1; j<=10; j = j + 1) {
    if (j == 5) {
      continue;
    }
    sum = sum + j;
  }
  return sum;
}
