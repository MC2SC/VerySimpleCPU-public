//EXPECTED 0

int main () {
    int a = 42;
    return a % a;
}
