#!/bin/bash                                                                                                                                                                                                 

OPT_PARAM=$1

for file in *.c
do
    EXPECTED=`grep EXPECTED $file | awk '{print $2}'`
    rm -f temp.asm
    ../vscompiler $OPT_PARAM $file > temp.asm
    ACTUAL=`../assembler_iss_mem_init_gen.py -i temp.asm -a 1 -s 0 | tail -n 5 | grep "mem\[ 11 \]" | awk '{print $5}'`
    if [ "$EXPECTED" == "$ACTUAL" ]; then
        echo -n "OK..... "
    else
        echo -n "==== FAIL!!! "
        echo "$file $EXPECTED vs $ACTUAL"
        exit
    fi
    echo "$file $EXPECTED vs $ACTUAL"
done

echo "ALL TESTS PASSED."

rm -f temp.asm mid.txt memin.txt program.v mem232.txt memoutd.txt memouth.txt
