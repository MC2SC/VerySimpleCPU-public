//EXPECTED 4

int main () {
    return 12 / 3;
}
