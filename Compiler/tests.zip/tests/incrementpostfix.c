//EXPECTED 41
int main() {
  int a = 20;
  int b = a++; 
  return a+b;
}
