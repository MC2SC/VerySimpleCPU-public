//EXPECTED 0

int main () {
    int a = 0;
    int b = 42;
    return a / b;
}
