//EXPECTED 42

int main() {
  int i;
  i = 2000;
  while (i) {
    i = i - 1;
  }
  return 42;
}
