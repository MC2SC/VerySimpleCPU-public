//EXPECTED 1
int main() {
  return -30 <= -12;
}
