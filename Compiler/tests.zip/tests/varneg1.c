//EXPECTED 4294967254
int main() {
  int a;
  a = -42;
  return a;
}
