//EXPECTED 42
int main() {
  return 60-18;
}
