//EXPECTED 4294966061
int main() {
  return ~1234;
}
