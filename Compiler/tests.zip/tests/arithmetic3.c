//EXPECTED 42
int main () {
    return 48 * 2 / 8 + (50 / 2 - 10) * 2;
}
