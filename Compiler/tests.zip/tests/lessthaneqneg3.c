//EXPECTED 1
int main() {
  return -12 <= -12;
}
