//EXPECTED 42
int main() {
  int a = 10;
  int b = 3 * 2 + 6;
  int c = 2 * 5 * 2;
  return a + b + c;
}
