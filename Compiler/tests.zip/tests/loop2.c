//EXPECTED 61
int main() {
  int i;
  int sum;
  sum = 0;
  for (i = 1; i <= 5; i=i+2) {
    int j;
    for (j = 0; j < 4; j=j+1) {
      sum = sum + i + j;
    }
  }
  
  return sum + i;
}
