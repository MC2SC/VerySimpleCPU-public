//EXPECTED 42

int tail(int n) {
  if (n) 
    return tail(n-1);
  else 
    return 42;
}

int main () {
    return tail(1000);
}