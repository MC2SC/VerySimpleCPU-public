//EXPECTED 2
int main() {
  return 0 - -2;
}
