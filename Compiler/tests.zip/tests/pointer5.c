//EXPECTED 42

int main() {
  int *p;                               // pointer to int
  int i;                                // int
  int ia[10];                           // array of 10 ints
  p = &i;                               // now p points to i
  *p = 227;                             // now i is 227
  *&i = 12;                             // now i is 12
  p = &*p;                              // no change
  p = ia;                               // now p points to ia[0]
  *ia = 42;                             // now ia[0] is 42
  return ia[0];                         // 42        
}