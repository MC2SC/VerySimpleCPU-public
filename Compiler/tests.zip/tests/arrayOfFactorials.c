//EXPECTED 24 

int a[5];			/* Must be global */
int main () {
    return loop(5);
}
int loop(int n) { 
  int i; 
  i = 0; 
  int f; 
  f = 1;
  while (i < n) {
    a[i] = f;
    i = i + 1;
    f = f * i;
  }
  return printarr(n, a);
}

int printarr(int len, int a[]) {
  return a[len-1]; 
}