//EXPECTED 4294967254
int main() {
  int a = 0 - 23;
  int b = 2;
  int c = ++a+b;
  return a+c;
}
