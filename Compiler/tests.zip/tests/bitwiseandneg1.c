//EXPECTED 17
int main() {
  return 17 & -15;
}
