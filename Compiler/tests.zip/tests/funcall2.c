//EXPECTED 19000
int foo(int b) {
  return b + 10000;
}

int baz(int a) {
  return foo(1000) + a;
}

int main() {
  return baz(8000);
}
