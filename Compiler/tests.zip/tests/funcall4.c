//EXPECTED 92
int foo(int a, int b, int c, int d) {
  return a + b + c + d;
}

int main() {
  int r;
  r = foo(3 + 5, 2 + 7, 1 + 9, 3 + 2);
  int k;
  k = 60;
  return r + k;
}
