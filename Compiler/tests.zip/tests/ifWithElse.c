//EXPECTED 42

int main() {
  int x = 0;
  if (x == 0) 
    return 42; 
  else 
    return 0;
}