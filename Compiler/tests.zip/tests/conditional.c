//EXPECTED 42

int main() {
   int a = 10;
   return (a == 10) ? 42: 30;
}