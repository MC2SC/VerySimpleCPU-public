//EXPECTED 35
int main() {
  int a[5];
  a[0] = 9;
  a[1] = 8;
  a[2] = 7;
  a[3] = 6;
  a[4] = 5;

  int *p;
  p = &(a[2]);
  
  return *(p-2) + *(p-1) + *p + *(p+1) + *(p+2);
}
