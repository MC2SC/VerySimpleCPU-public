//EXPECTED 42
int main() {
  int a = 14;
  a *= 3; 
  return a;
}
