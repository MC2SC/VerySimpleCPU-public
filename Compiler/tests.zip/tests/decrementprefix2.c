//EXPECTED 42
int main() {
  int a = 23;
  int b = 2;
  int c = --a-b;
  return a+c;
}
