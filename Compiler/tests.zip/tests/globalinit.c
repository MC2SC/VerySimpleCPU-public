//EXPECTED 42
int a = 42;

int main() {
  return a;
}
