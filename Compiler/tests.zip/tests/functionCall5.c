//EXPECTED 42

int main() {
    int arr[5];
    arr[0] = 1;
    arr[1] = 5;
    arr[2] = 7;
    arr[3] = 12;
    arr[4] = 17;
	
    return addnum(arr);
}
int addnum(int *ptr) {
    int index = 0;
    int total = 0;
    for (index = 0; index < 5; index = index + 1){
        total = total + (*(ptr + index));
    }
    return(total);
}
