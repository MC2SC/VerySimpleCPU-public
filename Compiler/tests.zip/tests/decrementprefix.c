//EXPECTED 42
int main() {
  int a = 22;
  int b = --a; 
  return a+b;
}
