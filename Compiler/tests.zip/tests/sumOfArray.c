//EXPECTED 42

int main() {
   int array[7];
   array[0] = 3;
   array[1] = 4;
   array[2] = 5;
   array[3] = 6;
   array[4] = 7;
   array[5] = 8;
   array[6] = 9;
   int loop;
   int sum = 0;
   for(loop = 0; loop < 7; loop = loop + 1) {
       sum = sum + array[loop];
   }
   return sum;
}
