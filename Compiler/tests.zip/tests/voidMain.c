//EXPECTED 5
void main() {
  5;
}
