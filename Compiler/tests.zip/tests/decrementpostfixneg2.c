//EXPECTED 4294967252
int main() {
  int a = 0 - 43;
  int b = 2;
  int c = a-b--;
  return b+c;
}
