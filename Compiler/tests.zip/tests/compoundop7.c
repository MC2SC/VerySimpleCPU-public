//EXPECTED 42
int main() {
  int a = 6;
  int b = 7;
  a *= b; 
  return a;
}
