//EXPECTED 8

int main () {
    int a = 42;
    int b = 5;
    return a / b;
}
