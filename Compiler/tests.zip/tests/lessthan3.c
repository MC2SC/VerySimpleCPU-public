//EXPECTED 0
int main() {
  return 12 < 12;
}
