//EXPECTED 8

int main () {
    return 42 / 5;
}
