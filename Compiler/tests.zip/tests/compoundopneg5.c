//EXPECTED 42
int main() {
  int a = 49;
  int b = -7;
  a += b; 
  return a;
}
