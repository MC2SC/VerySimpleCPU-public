//EXPECTED 42

int main() {
   int array[10];
   array [0] = 43;
   array [1] = 44;
   array [2] = 45;
   array [3] = 46;
   array [4] = 47;
   array [5] = 48;
   array [6] = 49;
   array [7] = 50;
   array [8] = 51;
   array [9] = 42;

   int loop;
   int smallest;

   smallest = array[0];
   
   for(loop = 1; loop < 10; loop = loop + 1) {
      if( smallest > array[loop] ) 
         smallest = array[loop];
   }
   return smallest;
}
