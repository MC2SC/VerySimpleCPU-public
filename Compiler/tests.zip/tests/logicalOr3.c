//EXPECTED 12
int main() {
  return 0 || 12;
}
