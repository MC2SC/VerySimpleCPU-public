//EXPECTED 4294967254
int main() {
  return -42;
}
