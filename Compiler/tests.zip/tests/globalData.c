//EXPECTED 42

int r;

int main() {
  int n;
  n = 1764;
  return sqrt(n);
}

int sqrt(int n) {
  r = 0;
  while (r * r < n) 
    r = r + 1;
  return r;
}