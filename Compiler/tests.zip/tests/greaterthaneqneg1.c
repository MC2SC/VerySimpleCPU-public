//EXPECTED 0
int main() {
  return -30 >= -12;
}
