//EXPECTED 35

int main () {
  int i = 0;
  int c = 0;
  while (i < 8) {
    i = i + 1;
    if (i == 6) continue;
    int j = 0;
    while (j < 5) {
      j = j + 1;
      if (j == 4) continue;
      c = c + 1;
    }
    c = c + 1;
  }
  return c;
}
