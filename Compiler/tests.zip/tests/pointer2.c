//EXPECTED 42
void foo(int *q) {
  *q = 42;
}

int main() {
  int a;
  int b;
  int c;
  int *p;
  int d;
  p = &c;
  foo(p);
  return c;
}
