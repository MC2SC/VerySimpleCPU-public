//EXPECTED 4294967257
int main() {
  int a = 0 - 20;
  int b = a++; 
  return a+b;
}
