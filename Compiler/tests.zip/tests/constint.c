//EXPECTED 42
int main() {
  return 42;
}
