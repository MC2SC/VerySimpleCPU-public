//EXPECTED 42

int operateWhile(int n) { 
  int i; 
  i=0; 
  while (i < n) {
    i=i+1;
  } 
  return 42;
}

int main () {
    return operateWhile(5);
}