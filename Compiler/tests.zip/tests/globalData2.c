//EXPECTED 42
int x;

int g(int y) {
  return x + y;
}

int main() {
  x = 12;
  return 16 + g(14);
}
