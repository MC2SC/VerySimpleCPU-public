//EXPECTED 42

int main() {
    int i = 42;
    if ( i == 0) {
        return 0;
    } else if ( i == 1) {
        return 1;
    } else if ( i == 2) {
        return 2;
    } else if ( i == 3) {
        return 3;
    } else if ( i == 4) {
        return 4;
    }
    else {
        return 42;
    }
}