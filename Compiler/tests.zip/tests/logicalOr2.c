//EXPECTED 3
int main() {
  return 3 || 0;
}
