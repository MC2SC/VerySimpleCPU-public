//EXPECTED 42
int main() {
  int a = 45;
  a -= 3; 
  return a;
}
