//EXPECTED 150

int main() {
   int n;
   int i;
   int j;
   int sum;
   n = 5;
   sum = 0;
   for(i = 1; i <= n; i = i + 1) {
      for(j = 1; j <= n; j = j + 1) {
        sum = sum +  j;
      }
      for(j = 1; j <= n; j = j + 1) {
        sum = sum + j;
      }
   }
   return sum;
}
