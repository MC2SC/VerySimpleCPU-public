//EXPECTED 4294967293
int main() {
  return (0 - 2) + (1 - 2);
}
