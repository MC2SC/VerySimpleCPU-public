//EXPECTED 42

int main () {
    return 76 + 3 * 8 - (30 + 70) / 2 - 8;
}