//EXPECTED 42
int main() {
  int a = 168;
  a /= 4; 
  return a;
}
