//EXPECTED 0

int main() {

    int a = -15;
    int b = 17;
    int c = 10;
    return (a | b) & c;
}
