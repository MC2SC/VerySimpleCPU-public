//EXPECTED 42

int main(){
    int var = 42;
    int *ptr2;
    int **ptr1;

    ptr2 = &var;
    ptr1 = &ptr2; 
    return **ptr1;
}
