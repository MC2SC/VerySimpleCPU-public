//EXPECTED 4294967254
int main() {
  int a = 0 - 22;
  int b = ++a; 
  return a+b;
}
