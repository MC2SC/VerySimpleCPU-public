//EXPECTED 14
int main() {
  return ~-15;
}
