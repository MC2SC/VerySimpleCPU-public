//EXPECTED 42

int getValue1() {
   return 42;
}

int getValue2(){
   return 21;
}

int main() {
   int a = 10;
   return (a == 10) ? getValue1() : getValue2();
}

