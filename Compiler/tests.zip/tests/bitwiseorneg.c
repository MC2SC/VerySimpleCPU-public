//EXPECTED 4294967281

int main() {

    int a = 17;
    int b = -15;
    return a | b;
}
