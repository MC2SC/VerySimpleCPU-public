//EXPECTED 42

int operateWhile(int n) {
  while (n > 0) {
    n = n - 1;
  }
  return 42;
}

int main () {
    return operateWhile(5);
}