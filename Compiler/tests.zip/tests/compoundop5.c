//EXPECTED 42
int main() {
  int a = 35;
  int b = 7;
  a += b; 
  return a;
}
