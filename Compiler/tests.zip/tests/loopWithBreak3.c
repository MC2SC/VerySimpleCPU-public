//EXPECTED 55

int main () {
  int sum = 0;
  int n;
  for (n = 0; n < 100; n = n + 1) {
    sum = sum + n;
    if (n == 10) {
      break;
    }
  }
  return sum;
}
