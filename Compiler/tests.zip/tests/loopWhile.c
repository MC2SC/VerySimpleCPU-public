//EXPECTED 55

int main () {
    int sum;
    int n = 0;
    while (n < 10) {
        n = n + 1;
        sum = sum + n;
    }
    return sum;
}
