//EXPECTED 1
int main() {
  return (0 - 12) >= (0 - 12);
}
