//EXPECTED 42
void operateFor(int n) {
  int i;
  for (i = n; i > 0; i = i - 1) {
  }
}

int main () {
    operateFor(100);    
    return 42;
}
