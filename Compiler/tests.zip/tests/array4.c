//EXPECTED 53
int main() {
  int a[5];
  a[0] = 9;
  a[1] = 8;
  a[2] = 7; // becomes 17
  a[3] = 6; // becomes 14
  a[4] = 5;

  int *p;
  p = &(a[2]);
  *p = *p + 10;

  int i;
  i = 4;
  a[i - 1] = a[i - 3] + a[i - 1];
  
  return a[0] + a[1] + a[2] + a[3] + a[4];
}
