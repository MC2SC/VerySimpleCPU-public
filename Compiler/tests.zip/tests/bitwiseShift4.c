//EXPECTED 0

int main() {
   return 61 << 32;
}
