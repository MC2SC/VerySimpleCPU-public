//EXPECTED 244

int main() {
   return 61 << 2;
}
