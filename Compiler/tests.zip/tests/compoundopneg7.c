//EXPECTED 42
int main() {
  int a = 0 - 6;
  int b = 0 - 7;
  a *= b; 
  return a;
}
