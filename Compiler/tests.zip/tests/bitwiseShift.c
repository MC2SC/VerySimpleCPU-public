//EXPECTED 15

int main() {
   return 60 >> 2;
}