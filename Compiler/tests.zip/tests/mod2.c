//EXPECTED 2

int main () {
    return 42 % 5;
}
