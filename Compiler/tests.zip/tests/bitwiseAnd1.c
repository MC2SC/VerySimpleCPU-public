//EXPECTED 8
int main() {
  return 12 & 10;
}
