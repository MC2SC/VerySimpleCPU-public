//EXPECTED 0
int main() {
  return (0 - 10) < (0 - 12);
}
