//EXPECTED 42
int main() {
  int a;
  int b;
  int c;
  int *p;
  int d;
  p = &c;
  p = p + 2;
  *(p - 2) = 42;
  return c;
}
