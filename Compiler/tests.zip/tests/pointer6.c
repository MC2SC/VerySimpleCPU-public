//EXPECTED 1

int main() {                     
  int (*iap)[10];                        // array of 10 ints
  return (&(*iap)[2] == &*((*iap)+2));   // 1 (true)
}