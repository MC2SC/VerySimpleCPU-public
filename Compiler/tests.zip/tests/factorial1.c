//EXPECTED 720
void fac(int n, int *res) {
  if (n == 0)			/* fac's n */
    *res = 1;
  else {
    int tmp;
    fac(n-1, &tmp);
    *res = tmp * n;
  }
}

int main() {
  int res;
  int i;
  i = 6;
  fac(i, &res);
  return res;
}

