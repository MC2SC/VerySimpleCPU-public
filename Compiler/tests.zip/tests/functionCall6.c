//EXPECTED 42

void swapnum ( int *var1, int *var2 ) {
   int tempnum;
   tempnum = *var1;
   *var1 = *var2;
   *var2 = tempnum;
}
int main( ) {
   int num1 = 41;
   int num2 = 42;
   swapnum( &num1, &num2 );
   return num1;
}
