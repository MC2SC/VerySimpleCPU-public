//EXPECTED 41
int main() {
  int a = 21;
  int b = a--; 
  return a+b;
}
