//EXPECTED 42
int main() {
  int x;
  x = 42;
  if (0 && x = 6) {
    return 0;
  } else {
    return x;
  }
}
