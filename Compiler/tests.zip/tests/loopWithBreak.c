//EXPECTED 55

int main () {
  int sum = 0;
  int n = 0;
  while (1) {
    n = n + 1;
    sum = sum + n;
    if (n == 10) {
      break;
    }
  }
  return sum;
}
