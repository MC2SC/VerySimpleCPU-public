//EXPECTED 42

int main() {
  int *p;                               // pointer to int
  int i;                                // int
  p = &i;                               // now p points to i
  *p = 227;                             // now i is 227
  *&i = 42;                             // now i is 42
  p = &*p;                              // no change
  return *p;                            // 42
}