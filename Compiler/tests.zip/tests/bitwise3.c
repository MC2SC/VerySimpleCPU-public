//EXPECTED 28

int main() {

    int a = 12;
    int b = 42;
    int c = 20;
    return (a & b ) | c;
}