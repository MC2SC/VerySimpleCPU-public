//EXPECTED 4294967295
int main() {
  return -31 != -30;
}
