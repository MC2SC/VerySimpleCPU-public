//EXPECTED 120

int main() {
  int r;
  fac(5, &r);
  return r;
}

void fac(int n, int *res) {
  if (n == 0)
    *res = 1;
  else {
    int tmp;
    fac(n-1, &tmp);
    *res = tmp * n;
  }
}