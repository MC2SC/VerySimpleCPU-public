//EXPECTED 42

int main() {
   int a = 10;
   int b = 20;
   return (a != 10) ? ((a <= 15) ? 42: 30) : ((b >= 15) ? 42: 30);
}
