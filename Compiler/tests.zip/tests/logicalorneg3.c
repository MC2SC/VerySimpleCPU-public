//EXPECTED 4294967284
int main() {
  return 0 || -12;
}
