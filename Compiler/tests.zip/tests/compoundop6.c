//EXPECTED 42
int main() {
  int a = 50;
  int b = 8;
  a -= b; 
  return a;
}
