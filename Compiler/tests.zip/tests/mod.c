//EXPECTED 2

int main () {
    return 2 % 5;
}
