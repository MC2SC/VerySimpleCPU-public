//EXPECTED 154
int a[6]; /* Must be global */

int sum(int len, int a[]) {
  int i; 
  i = 0;
  int sum;
  sum = 0;
  while (i < len) { 
    sum = sum + a[i]; 
    i = i + 1; 
  }
  return sum;
}

int main() {
  int n;
  n = 6;
  int i; 
  i = 0; 
  int f; 
  f = 1;
  while (i < n) {
    a[i] = f;
    i = i + 1;
    f = f * i;
  }
  return sum(n, a); // 1 + 1 + 2 + 6 + 24 + 120
}

