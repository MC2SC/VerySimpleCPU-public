//EXPECTED 19000
int foo() {
  return 10000;
}

int baz() {
  return foo() + 1000;
}

int main() {
  return 8000 + baz();
}
