//EXPECTED 42
int main() {
  if(4+5)
    return 3*14;
  else
    return 3*33;
}
