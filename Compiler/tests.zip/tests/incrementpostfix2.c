//EXPECTED 42
int main() {
  int a = 37;
  int b = 2;
  int c = a+b++;
  return b+c;
}
