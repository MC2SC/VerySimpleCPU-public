//EXPECTED 4294967295
int main() {
  return (0 - 2) + (3 - 2);
}
