//EXPECTED 120
int main() {
  int i;
  i = 0;
  while (i < 5) {
    fac(i);
    i = i + 1;
  }
  return fac(i);
}

int fac(int n) {
  if (n == 0)			/* fac's n */
    return 1;
  else 
    return n * fac(n-1);
}