//EXPECTED 42
int main() {
  int a;
  a = 42;
  return a;
}
