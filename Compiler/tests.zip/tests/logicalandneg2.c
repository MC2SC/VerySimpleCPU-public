//EXPECTED 0
int main() {
  return -3 && 0;
}
