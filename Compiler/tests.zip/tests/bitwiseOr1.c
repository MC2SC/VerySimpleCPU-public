//EXPECTED 14
int main() {
  return 12 | 10;
}
