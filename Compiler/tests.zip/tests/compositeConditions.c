//EXPECTED 0

int main() {
  int b;
  int m;
  int n;
  m = 1;
  n = 1;
  if (m == 0 && n == 0){
  } else {
  }
  b = (m == 0 && n == 0);
  return b;
}
