//EXPECTED 42

int main(){
    int num1 = 40;
    int num2 = 41;
    int num3= 42;
    if (num1 > num2) {
        if (num1 > num3) {
            return num1;
        }
        else {
            return num3;
        }
    } else {
        if (num2 > num3)
            return num2;
        else 
            return num3;
    }
}