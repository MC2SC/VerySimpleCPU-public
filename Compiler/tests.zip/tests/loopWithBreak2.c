//EXPECTED 30

int main () {
  int i = 0;
  int c = 0;
  while (1) {
    if (i == 6) break;
    int j = 0;
    while (1) {
      if (j == 4) break;
      j = j + 1;
      c = c + 1;
    }
    i = i + 1;
    c = c + 1;
  }
  return c;
}
