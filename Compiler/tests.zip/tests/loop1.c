//EXPECTED 55
int main() {
  int i;
  int sum;
  sum = 0;
  for (i = 1; i <= 10; i=i+1) {
    sum = sum + i;
  }
  
  return sum;
}
