//EXPECTED 42
int main() {
  return 9 + 4 + 5 * (3 + 10) - 36;
}
