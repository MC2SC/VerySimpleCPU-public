//EXPECTED 4294967252
int main() {
  int a = 0 - 21;
  int b = --a; 
  return a+b;
}
