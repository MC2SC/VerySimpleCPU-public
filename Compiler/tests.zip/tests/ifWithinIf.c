//EXPECTED 42

int main() {
  int m = 0; 
  int n = 0;
  if (m == 0) {
    if (n == 0) {
      return 42;
    }
  } else
    return 0;
}
