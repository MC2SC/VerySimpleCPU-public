//EXPECTED 42
int foo() {
  return 12;
}

int main() {
  int a = 10;
  int b = foo();
  int c = 2 * 5 * 2;
  return a + b + c;
}
