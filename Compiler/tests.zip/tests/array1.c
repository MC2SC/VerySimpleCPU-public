//EXPECTED 7
int main() {
  int a[5];
  
  a[2] = 7;

  return a[2];
}
