//EXPECTED 42
int main() {
  if(1)
    return 42;
  else
    return 99;
}
