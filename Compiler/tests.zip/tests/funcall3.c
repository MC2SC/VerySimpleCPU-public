//EXPECTED 8000
int foo() {
  return 10000;
}

int main() {
  foo();
  return 8000;
}
