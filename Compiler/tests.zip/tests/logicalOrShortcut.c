//EXPECTED 42
int main() {
  int x;
  x = 42;
  if (78 || x = 6) {
    return x;
  } else {
    return 0;
  }
}
