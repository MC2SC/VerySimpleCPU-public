//EXPECTED 42
int main() {
  return 14*3;
}
