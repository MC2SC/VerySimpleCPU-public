//EXPECTED 4294967252
int main() {
  int a;
  int b;
  int c;
  if (1) {
    int d;
    c = -3 * 3 + 3;
    int e;
  }
  int f;
  int g;
  g = -4 * 5 + -2 * 5;
  int h;
  h = 3 * -5 + 7;
  return c + g + h;
}
