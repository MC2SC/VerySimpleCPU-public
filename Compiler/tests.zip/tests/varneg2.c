//EXPECTED 4294967260
int main() {
  int a;
  int b;
  int c;
  int d;
  c = -3 * 3 + 3;
  int e;
  int f;
  e = -4 * 5 + -2 * 5;
  int g;
  return c + e;
}
