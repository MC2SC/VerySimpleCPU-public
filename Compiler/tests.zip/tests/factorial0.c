//EXPECTED 1
int fact(int n) {
  if (n <= 0) {
    return 1;
  } else {
    return n * fact(n-1);
  }
}

int main() {
  int r;
  int n;
  n = 6;
  r = fact(n);

  int f;
  f = 1;
  int i;
  for (i = 1; i <= n; i = i + 1) {
    f = f * i;
  }
  
  return (f == 720) && (f == r);
}
