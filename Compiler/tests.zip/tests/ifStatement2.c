//EXPECTED 42

int main() {
    int m=41;
    int n=42;
    if (m>n) {
        return 41;
    }
    else if(m<n) {
        return 42;
    }
    else {
        return 0;
    }
}
