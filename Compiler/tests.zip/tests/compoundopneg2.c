//EXPECTED 42
int main() {
  int a = 39;
  a -= -3; 
  return a;
}
