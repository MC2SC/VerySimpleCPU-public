//EXPECTED 12
int main() {
  return 3 && 12;
}
