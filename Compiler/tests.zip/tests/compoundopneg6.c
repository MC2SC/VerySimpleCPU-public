//EXPECTED 42
int main() {
  int a = 34;
  int b = 0 - 8;
  a -= b; 
  return a;
}
